import React, { useState, useEffect } from "react";
import {
  LayoutDashboard,
  BedSingle,
  HandCoins,
  LogOut,
  CheckCircle2,
  Home,
  Package,
  QrCode,
  CheckSquare,
  Megaphone,
  MessageSquare,
  AlertCircle,
  FileText,
  Upload,
  Wrench,
  Users,
} from "lucide-react";

// แยกข้อมูลแอดมินออกมาเป็นค่าคงที่
const ADMIN_USER = "admin";
const ADMIN_PASS = "admin1234";

export default function App() {
  // localStorage.clear();

  const [role, setRole] = useState(null);
  const [currentUser, setCurrentUser] = useState(null);
  const [activeMenu, setActiveMenu] = useState("Dashboard");

  const WATER_RATE = 4;
  const ELECTRIC_RATE = 7;

  // ==========================================
  // 1. ระบบดึงข้อมูล (LocalStorage)
  // ==========================================
  const [rooms, setRooms] = useState(() => {
    const saved = localStorage.getItem("dorm_master_data");
    if (saved) return JSON.parse(saved);
    const initial = [];
    for (let floor = 1; floor <= 5; floor++) {
      for (let i = 1; i <= 5; i++) {
        let roomNum = `${floor}0${i}`;
        initial.push({
          number: roomNum,
          floor,
          status: roomNum === "101" ? "Occupied" : "Available",
          tenant: roomNum === "101" ? "ผู้เช่าห้อง" : "-",
          password: "1234",
          paymentStatus: "none",
          rent: 3500,
          prevWater: 0,
          currWater: 0,
          waterBill: 0,
          prevElectric: 500,
          currElectric: 500,
          electricBill: 0,
          totalBill: 3500,
          parcels: 0,
          contractDate: "01/01/2026",
          slipImage: null,
          billingHistory: [],
        });
      }
    }
    return initial;
  });

  const [announcements, setAnnouncements] = useState(() => {
    const saved = localStorage.getItem("dorm_news_data");
    return saved
      ? JSON.parse(saved)
      : [
          {
            id: 1,
            title: "ประกาศเริ่มต้น",
            content: "ยินดีต้อนรับสู่ระบบจัดการหอพัก S.T. Dormitory",
            date: new Date().toLocaleDateString("th-TH"),
          },
        ];
  });

  const [complaints, setComplaints] = useState(() => {
    const saved = localStorage.getItem("dorm_complaints_data");
    return saved ? JSON.parse(saved) : [];
  });

  // ==========================================
  // 2. ระบบเซฟข้อมูล (Auto-Save)
  // ==========================================
  useEffect(() => {
    localStorage.setItem("dorm_master_data", JSON.stringify(rooms));
  }, [rooms]);
  useEffect(() => {
    localStorage.setItem("dorm_news_data", JSON.stringify(announcements));
  }, [announcements]);
  useEffect(() => {
    localStorage.setItem("dorm_complaints_data", JSON.stringify(complaints));
  }, [complaints]);

  // ==========================================
  // LOGIN LOGIC
  // ==========================================
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [loginTab, setLoginTab] = useState("user");

  const handleLogin = (e) => {
    e.preventDefault();
    if (loginTab === "admin") {
      if (username === ADMIN_USER && password === ADMIN_PASS) {
        setRole("admin");
        setActiveMenu("Dashboard");
      } else {
        alert("ชื่อผู้ใช้หรือรหัสแอดมินผิด!");
      }
    } else {
      const found = rooms.find((r) => r.number === username);
      if (
        found &&
        found.status === "Occupied" &&
        password === (found.password || "1234")
      ) {
        setCurrentUser(username);
        setRole("user");
        setActiveMenu("Home");
      } else {
        alert("ไม่พบห้องนี้ หรือรหัสผ่านผิด!");
      }
    }
  };

  // ==========================================
  // ADMIN FUNCTIONS
  // ==========================================
  const [meterForm, setMeterForm] = useState({
    room: "",
    water: "",
    electric: "",
  });

  const processBilling = () => {
    if (!meterForm.room) return alert("กรุณาเลือกห้อง!");
    if (!meterForm.water || !meterForm.electric)
      return alert("กรุณากรอกเลขมิเตอร์ให้ครบ!");

    setRooms(
      rooms.map((r) => {
        if (r.number === meterForm.room) {
          const wUnits = Number(meterForm.water) - r.currWater;
          const eUnits = Number(meterForm.electric) - r.currElectric;

          if (wUnits < 0 || eUnits < 0) {
            alert("เลขมิเตอร์ใหม่ต้องมากกว่าหรือเท่ากับเลขเดิม!");
            return r;
          }

          const newTotal =
            r.rent + wUnits * WATER_RATE + eUnits * ELECTRIC_RATE;

          const newBillRecord = {
            id: Date.now(),
            date: new Date().toLocaleDateString("th-TH"),
            prevW: r.currWater,
            currW: Number(meterForm.water),
            waterBill: wUnits * WATER_RATE,
            prevE: r.currElectric,
            currE: Number(meterForm.electric),
            electricBill: eUnits * ELECTRIC_RATE,
            totalBill: newTotal,
          };

          alert("ออกบิลสำเร็จ!");
          return {
            ...r,
            prevWater: r.currWater,
            currWater: Number(meterForm.water),
            prevElectric: r.currElectric,
            currElectric: Number(meterForm.electric),
            waterBill: wUnits * WATER_RATE,
            electricBill: eUnits * ELECTRIC_RATE,
            totalBill: newTotal,
            paymentStatus: "unpaid",
            slipImage: null,
            billingHistory: [newBillRecord, ...(r.billingHistory || [])],
          };
        }
        return r;
      })
    );
    setMeterForm({ room: "", water: "", electric: "" });
  };

  // ==========================================
  // USER FUNCTIONS (Upload Slip)
  // ==========================================
  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setRooms(
          rooms.map((room) =>
            room.number === currentUser
              ? { ...room, paymentStatus: "pending", slipImage: reader.result }
              : room
          )
        );
        alert("ส่งสลิปสำเร็จ! รอแอดมินตรวจสอบ");
      };
      reader.readAsDataURL(file);
    }
  };

  // ==========================================
  // UI: LOGIN PAGE
  // ==========================================
  if (!role) {
    return (
      <div className="min-h-screen bg-slate-100 flex items-center justify-center p-6 font-sarabun">
        <div className="bg-white p-12 rounded-[50px] shadow-2xl max-w-md w-full border border-slate-50 text-center">
          <div className="bg-sky-600 w-16 h-16 rounded-[22px] flex items-center justify-center mx-auto mb-6 shadow-lg shadow-sky-100">
            <BedSingle className="text-white" size={32} />
          </div>
          <h1 className="text-3xl font-black mb-8 tracking-tighter uppercase">
            S.T. Dormitory
          </h1>
          <div className="flex mb-10 bg-slate-100 p-1.5 rounded-2xl">
            <button
              onClick={() => {
                setLoginTab("user");
                setUsername("");
                setPassword("");
              }}
              className={`flex-1 py-3 rounded-xl font-bold transition-all ${
                loginTab === "user"
                  ? "bg-white shadow text-sky-600"
                  : "text-slate-400"
              }`}
            >
              ผู้เช่า
            </button>
            <button
              onClick={() => {
                setLoginTab("admin");
                setUsername("");
                setPassword("");
              }}
              className={`flex-1 py-3 rounded-xl font-bold transition-all ${
                loginTab === "admin"
                  ? "bg-white shadow text-sky-600"
                  : "text-slate-400"
              }`}
            >
              แอดมิน
            </button>
          </div>
          <form onSubmit={handleLogin} className="space-y-6 text-left">
            <input
              type="text"
              placeholder={loginTab === "user" ? "Username" : "Username"}
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full p-5 bg-slate-50 border-none rounded-[22px] outline-none font-bold"
              required
            />
            <input
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full p-5 bg-slate-50 border-none rounded-[22px] outline-none font-bold"
              required
            />
            <button className="w-full py-5 bg-slate-900 text-white font-black rounded-[22px] hover:bg-black transition-all">
              SIGN IN
            </button>
          </form>
        </div>
      </div>
    );
  }

  const r =
    role === "user" ? rooms.find((room) => room.number === currentUser) : null;
  const pendingCount = rooms.filter(
    (rm) => rm.paymentStatus === "pending"
  ).length;

  return (
    <div className="min-h-screen bg-[#FDFDFD] flex flex-col md:flex-row font-sarabun text-slate-800">
      {/* Sidebar */}
      <div className="w-full md:w-72 bg-white border-r border-slate-100 p-8 flex flex-col z-20">
        <h2 className="font-black text-sky-600 text-2xl mb-12 italic uppercase tracking-tighter border-b-2 pb-4 border-sky-50">
          S.T. {role}
        </h2>
        <nav className="flex-1 space-y-4 font-bold text-sm">
          {role === "user" ? (
            <>
              <button
                onClick={() => setActiveMenu("Home")}
                className={`w-full flex items-center gap-4 p-4 rounded-2xl ${
                  activeMenu === "Home"
                    ? "bg-sky-600 text-white shadow-lg"
                    : "text-slate-400 hover:bg-slate-50"
                }`}
              >
                <Home size={20} /> หน้าหลัก
              </button>
              <button
                onClick={() => setActiveMenu("Bill")}
                className={`w-full flex items-center gap-4 p-4 rounded-2xl ${
                  activeMenu === "Bill"
                    ? "bg-sky-600 text-white shadow-lg"
                    : "text-slate-400 hover:bg-slate-50"
                }`}
              >
                <HandCoins size={20} /> บิลค่าเช่า
              </button>
              <button
                onClick={() => setActiveMenu("News")}
                className={`w-full flex items-center gap-4 p-4 rounded-2xl ${
                  activeMenu === "News"
                    ? "bg-sky-600 text-white shadow-lg"
                    : "text-slate-400 hover:bg-slate-50"
                }`}
              >
                <Megaphone size={20} /> ข่าวสาร
              </button>
              <button
                onClick={() => setActiveMenu("Complaint")}
                className={`w-full flex items-center gap-4 p-4 rounded-2xl ${
                  activeMenu === "Complaint"
                    ? "bg-sky-600 text-white shadow-lg"
                    : "text-slate-400 hover:bg-slate-50"
                }`}
              >
                <MessageSquare size={20} /> ร้องเรียน
              </button>
              <button
                onClick={() => setActiveMenu("Contract")}
                className={`w-full flex items-center gap-4 p-4 rounded-2xl ${
                  activeMenu === "Contract"
                    ? "bg-sky-600 text-white shadow-lg"
                    : "text-slate-400 hover:bg-slate-50"
                }`}
              >
                <FileText size={20} /> Contract
              </button>
            </>
          ) : (
            <>
              <button
                onClick={() => setActiveMenu("Dashboard")}
                className={`w-full flex items-center gap-4 p-4 rounded-2xl ${
                  activeMenu === "Dashboard"
                    ? "bg-sky-600 text-white shadow-lg"
                    : "text-slate-500 hover:text-white"
                }`}
              >
                <LayoutDashboard size={20} /> Dashboard
              </button>
              <button
                onClick={() => setActiveMenu("ManageRooms")}
                className={`w-full flex items-center gap-4 p-4 rounded-2xl ${
                  activeMenu === "ManageRooms"
                    ? "bg-sky-600 text-white shadow-lg"
                    : "text-slate-500 hover:text-white"
                }`}
              >
                <BedSingle size={20} /> ผังห้อง/มิเตอร์
              </button>
              <button
                onClick={() => setActiveMenu("AdminParcels")}
                className={`w-full flex items-center gap-4 p-4 rounded-2xl ${
                  activeMenu === "AdminParcels"
                    ? "bg-sky-600 text-white shadow-lg"
                    : "text-slate-500 hover:text-white"
                }`}
              >
                <Package size={20} /> จัดการพัสดุ
              </button>
              <button
                onClick={() => setActiveMenu("AdminPR")}
                className={`w-full flex items-center gap-4 p-4 rounded-2xl ${
                  activeMenu === "AdminPR"
                    ? "bg-sky-600 text-white shadow-lg"
                    : "text-slate-500 hover:text-white"
                }`}
              >
                <Megaphone size={20} /> ประกาศข่าว
              </button>
              {/* ✅ อัปเดตตัวนับจำนวนร้องเรียน ให้ไม่นับรายการที่เสร็จแล้ว */}
              <button
                onClick={() => setActiveMenu("AdminComplaint")}
                className={`w-full flex items-center gap-4 p-4 rounded-2xl ${
                  activeMenu === "AdminComplaint"
                    ? "bg-sky-600 text-white shadow-lg"
                    : "text-slate-500 hover:text-white"
                }`}
              >
                <MessageSquare size={20} /> ร้องเรียน (
                {
                  complaints.filter(
                    (c) =>
                      c.status !== "ซ่อมเสร็จแล้ว" &&
                      c.status !== "จัดการเรียบร้อย"
                  ).length
                }
                )
              </button>
              <button
                onClick={() => setActiveMenu("Verify")}
                className={`w-full flex items-center gap-4 p-4 rounded-2xl ${
                  activeMenu === "Verify"
                    ? "bg-sky-600 text-white shadow-lg"
                    : "text-slate-500 hover:text-white"
                }`}
              >
                <CheckSquare size={20} /> ตรวจสลิป ({pendingCount})
              </button>
            </>
          )}
        </nav>
        <button
          onClick={() => {
            setRole(null);
            setCurrentUser(null);
            setActiveMenu("Dashboard");
            setUsername("");
            setPassword("");
          }}
          className="flex items-center gap-4 text-red-400 p-4 mt-auto font-black italic tracking-widest uppercase hover:bg-red-50 rounded-2xl transition-all"
        >
          <LogOut size={20} /> LOGOUT
        </button>
      </div>

      <div className="flex-1 p-10 overflow-y-auto">
        {/* ================= USER CONTENT ================= */}
        {role === "user" && activeMenu === "Home" && (
          <div className="space-y-10">
            <h1 className="text-4xl font-black italic tracking-tighter">
              ROOM {currentUser}
            </h1>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 font-black uppercase tracking-tight">
              <div className="bg-white p-10 rounded-[45px] shadow-sm border border-slate-100">
                <p className="text-slate-400 text-[10px] tracking-widest mb-4">
                  Current Balance
                </p>
                <h2 className="text-5xl">฿ {r.totalBill.toLocaleString()}</h2>
                <div
                  className={`mt-6 inline-block px-4 py-1.5 rounded-full text-[10px] ${
                    r.paymentStatus === "paid"
                      ? "bg-green-100 text-green-600"
                      : r.paymentStatus === "pending"
                      ? "bg-yellow-100 text-yellow-600"
                      : "bg-red-100 text-red-600"
                  }`}
                >
                  {r.paymentStatus === "pending"
                    ? "PENDING VERIFY"
                    : r.paymentStatus}
                </div>
              </div>
              <div className="bg-slate-900 p-10 rounded-[45px] text-white flex items-center gap-8 shadow-xl">
                <div className="bg-slate-800 p-6 rounded-[30px] text-sky-400">
                  <Package size={40} />
                </div>
                <div>
                  <p className="text-slate-500 text-[10px] tracking-widest">
                    Parcels
                  </p>
                  <h2 className="text-4xl">
                    {r.parcels}{" "}
                    <span className="text-sm font-bold text-slate-400 tracking-normal text-[10px]">
                      ITEMS
                    </span>
                  </h2>
                </div>
              </div>
            </div>
          </div>
        )}

        {role === "user" && activeMenu === "Bill" && (
          <div className="max-w-4xl space-y-8">
            <div className="bg-white p-12 rounded-[60px] shadow-sm border border-slate-100 flex flex-col md:flex-row gap-12 font-bold italic">
              <div className="flex-1 space-y-8">
                <h2 className="text-3xl font-black border-b-2 pb-6 uppercase tracking-tighter">
                  Bill Invoice
                </h2>
                <div className="space-y-6">
                  <div className="flex justify-between text-lg text-slate-500">
                    <span>ค่าเช่าห้องพัก</span>
                    <span className="text-slate-800">
                      ฿ {r.rent.toLocaleString()}
                    </span>
                  </div>
                  <div className="flex justify-between text-lg text-slate-500">
                    <div>
                      <p>ค่าน้ำ</p>
                      <p className="text-[10px] uppercase font-black">
                        ({r.prevWater} ➔ {r.currWater})
                      </p>
                    </div>
                    <span className="text-slate-800">
                      ฿ {r.waterBill.toLocaleString()}
                    </span>
                  </div>
                  <div className="flex justify-between text-lg text-slate-500 border-b-2 pb-8">
                    <div>
                      <p>ค่าไฟ</p>
                      <p className="text-[10px] uppercase font-black">
                        ({r.prevElectric} ➔ {r.currElectric})
                      </p>
                    </div>
                    <span className="text-slate-800">
                      ฿ {r.electricBill.toLocaleString()}
                    </span>
                  </div>
                  <div className="flex justify-between text-5xl font-black text-sky-600 pt-6 tracking-tighter uppercase">
                    <span>Total</span>
                    <span>฿ {r.totalBill.toLocaleString()}</span>
                  </div>
                </div>
              </div>
              <div className="w-full md:w-80 flex flex-col items-center justify-center border-l-2 border-slate-50 pl-12">
                {r.paymentStatus === "unpaid" ? (
                  <>
                    <QrCode size={180} className="mb-8" />
                    <input
                      type="file"
                      id="slip-upload"
                      accept="image/*"
                      className="hidden"
                      onChange={handleFileUpload}
                    />
                    <label
                      htmlFor="slip-upload"
                      className="w-full bg-sky-600 text-white font-black py-5 rounded-[22px] shadow-xl hover:bg-sky-700 transition-all uppercase text-sm tracking-widest italic cursor-pointer flex items-center justify-center gap-2"
                    >
                      <Upload size={18} /> Upload Slip
                    </label>
                  </>
                ) : (
                  <div className="text-center">
                    <CheckCircle2
                      size={100}
                      className={`${
                        r.paymentStatus === "pending"
                          ? "text-yellow-400"
                          : "text-green-500"
                      } mb-6 mx-auto`}
                    />
                    <h3 className="text-2xl font-black uppercase italic tracking-tighter">
                      {r.paymentStatus === "pending"
                        ? "Pending Verify"
                        : "Paid Success"}
                    </h3>
                  </div>
                )}
              </div>
            </div>

            {r.billingHistory && r.billingHistory.length > 0 && (
              <div className="bg-white p-10 rounded-[50px] shadow-sm border border-slate-100">
                <h3 className="text-2xl font-black mb-6 uppercase tracking-tighter border-b-2 pb-4 italic">
                  ประวัติบิลย้อนหลัง
                </h3>
                <div className="space-y-4">
                  {r.billingHistory.map((bill) => (
                    <div
                      key={bill.id}
                      className="p-6 bg-slate-50 rounded-[25px] flex flex-col md:flex-row justify-between items-center gap-4"
                    >
                      <div>
                        <p className="font-black text-lg">
                          รอบบิล: {bill.date}
                        </p>
                        <p className="text-xs text-slate-500 font-bold mt-1">
                          น้ำ: {bill.currW - bill.prevW} หน่วย | ไฟ:{" "}
                          {bill.currE - bill.prevE} หน่วย
                        </p>
                      </div>
                      <span className="text-2xl font-black text-sky-600 italic tracking-tighter">
                        ฿ {bill.totalBill.toLocaleString()}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {role === "user" && activeMenu === "News" && (
          <div className="max-w-3xl mx-auto space-y-6">
            <h1 className="text-3xl font-black italic uppercase tracking-tighter">
              Announcements
            </h1>
            {announcements.map((ann) => (
              <div
                key={ann.id}
                className="bg-white p-8 rounded-[40px] shadow-sm border border-slate-100"
              >
                <h3 className="text-xl font-black mb-2 text-sky-600 uppercase italic tracking-tighter">
                  {ann.title}
                </h3>
                <p className="text-slate-500 font-bold mb-4">{ann.content}</p>
                <p className="text-[10px] font-black text-slate-300 italic uppercase">
                  {ann.date}
                </p>
              </div>
            ))}
          </div>
        )}

        {role === "user" && activeMenu === "Complaint" && (
          <div className="max-w-2xl mx-auto">
            <div className="bg-white p-10 rounded-[50px] shadow-sm border border-red-50 mb-10">
              <h2 className="text-2xl font-black mb-8 flex items-center gap-3 text-red-500 uppercase tracking-tighter italic">
                <AlertCircle /> แจ้งปัญหา/ร้องเรียน
              </h2>
              <form
                className="space-y-6"
                onSubmit={(e) => {
                  e.preventDefault();
                  setComplaints([
                    {
                      id: Date.now(),
                      room: currentUser,
                      type: e.target.type.value,
                      topic: e.target.topic.value,
                      detail: e.target.detail.value,
                      status: "รอดำเนินการ",
                      date: new Date().toLocaleDateString("th-TH"),
                    },
                    ...complaints,
                  ]);
                  e.target.reset();
                  alert("ส่งเรื่องสำเร็จ!");
                }}
              >
                <select
                  name="type"
                  className="w-full p-5 bg-slate-50 border-none rounded-[25px] font-black outline-none text-slate-600 cursor-pointer"
                  required
                >
                  <option value="">-- เลือกประเภทปัญหา --</option>
                  <option value="แจ้งซ่อม">
                    แจ้งซ่อม (ภายในห้อง/พื้นที่ส่วนกลาง)
                  </option>
                  <option value="ร้องเรียน">
                    ร้องเรียนผู้เช่า (เสียงดัง/จอดรถขวาง ฯลฯ)
                  </option>
                </select>

                <input
                  name="topic"
                  placeholder="หัวเรื่อง (เช่น แอร์ไม่เย็น, ห้องข้างๆ เสียงดัง)"
                  className="w-full p-5 bg-slate-50 border-none rounded-[25px] font-black outline-none"
                  required
                />
                <textarea
                  name="detail"
                  rows="4"
                  placeholder="ระบุรายละเอียดเพิ่มเติม..."
                  className="w-full p-5 bg-slate-50 border-none rounded-[25px] font-bold outline-none"
                  required
                ></textarea>
                <button className="w-full bg-red-500 text-white font-black py-5 rounded-[25px] uppercase text-xs tracking-widest italic hover:bg-red-600 transition-all">
                  Submit Report
                </button>
              </form>
            </div>

            <div>
              <h3 className="text-xl font-black mb-6 uppercase tracking-tighter border-b-2 pb-4">
                ประวัติการแจ้งเรื่องของฉัน
              </h3>
              {complaints.filter((c) => c.room === currentUser).length === 0 ? (
                <p className="text-slate-400 font-bold text-sm">
                  ยังไม่มีรายการแจ้งเรื่อง
                </p>
              ) : (
                <div className="space-y-4">
                  {complaints
                    .filter((c) => c.room === currentUser)
                    .map((comp) => (
                      <div
                        key={comp.id}
                        className="bg-white p-6 rounded-[25px] shadow-sm border flex justify-between items-center"
                      >
                        <div>
                          <div className="flex items-center gap-2 mb-1">
                            <span
                              className={`px-2 py-1 rounded text-[10px] font-black tracking-widest text-white ${
                                comp.type === "แจ้งซ่อม"
                                  ? "bg-sky-500"
                                  : "bg-purple-500"
                              }`}
                            >
                              {comp.type}
                            </span>
                            <p className="font-black text-lg">{comp.topic}</p>
                          </div>
                          <p className="text-xs text-slate-400 font-bold">
                            วันที่: {comp.date}
                          </p>
                        </div>
                        {/* ✅ อัปเดตสี Badge ตามสถานะที่ปรับใหม่ */}
                        <span
                          className={`px-4 py-2 rounded-full text-[10px] font-black tracking-widest ${
                            comp.status === "รอดำเนินการ"
                              ? "bg-red-100 text-red-600"
                              : comp.status === "กำลังซ่อม" ||
                                comp.status === "รับเรื่องแล้ว"
                              ? "bg-yellow-100 text-yellow-600"
                              : "bg-green-100 text-green-600"
                          }`}
                        >
                          {comp.status}
                        </span>
                      </div>
                    ))}
                </div>
              )}
            </div>
          </div>
        )}

        {role === "user" && activeMenu === "Contract" && (
          <div className="max-w-2xl mx-auto bg-white p-12 rounded-[50px] shadow-sm border font-black italic">
            <h2 className="text-3xl mb-10 border-b-2 pb-6 uppercase tracking-tighter italic">
              Digital Contract
            </h2>
            <div className="space-y-6 text-xl">
              <div className="flex justify-between text-slate-400 uppercase text-xs">
                <span>Room Number</span>
                <span className="text-slate-800 text-xl tracking-tighter uppercase">
                  {r.number}
                </span>
              </div>
              <div className="flex justify-between text-slate-400 uppercase text-xs">
                <span>Tenant Name</span>
                <span className="text-slate-800 text-xl tracking-tighter uppercase">
                  {r.tenant}
                </span>
              </div>
              <div className="flex justify-between text-slate-400 uppercase text-xs">
                <span>Contract Date</span>
                <span className="text-slate-800 text-xl tracking-tighter uppercase">
                  {r.contractDate}
                </span>
              </div>
            </div>
          </div>
        )}

        {/* ================= ADMIN CONTENT ================= */}
        {role === "admin" && activeMenu === "Dashboard" && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-10 font-black italic text-center tracking-tighter uppercase">
            <div className="bg-white p-12 rounded-[60px] border-b-[10px] border-sky-500 shadow-sm">
              <p className="text-slate-400 text-[10px] tracking-widest mb-4">
                Tenants
              </p>
              <h2 className="text-7xl">
                {rooms.filter((rm) => rm.status === "Occupied").length}
              </h2>
            </div>
            <div className="bg-white p-12 rounded-[60px] border-b-[10px] border-red-500 shadow-sm">
              <p className="text-slate-400 text-[10px] tracking-widest mb-4">
                Wait Slip
              </p>
              <h2 className="text-7xl text-red-600">{pendingCount}</h2>
            </div>
          </div>
        )}

        {role === "admin" && activeMenu === "ManageRooms" && (
          <div className="space-y-12">
            <h1 className="text-3xl font-black italic uppercase tracking-tighter underline decoration-sky-500">
              Meter Management
            </h1>
            <div className="bg-white p-10 rounded-[50px] shadow-sm border grid grid-cols-1 md:grid-cols-4 gap-8 items-end font-black uppercase text-[10px] tracking-widest">
              <div>
                <label className="ml-2 mb-3 block">เลือกห้อง</label>
                <select
                  onChange={(e) => {
                    const selectedRoomNum = e.target.value;
                    const foundRoom = rooms.find(
                      (r) => r.number === selectedRoomNum
                    );
                    setMeterForm({
                      room: selectedRoomNum,
                      water: foundRoom ? foundRoom.currWater.toString() : "",
                      electric: foundRoom
                        ? foundRoom.currElectric.toString()
                        : "",
                    });
                  }}
                  value={meterForm.room}
                  className="w-full p-4 bg-slate-50 border-none rounded-2xl outline-none text-xs"
                >
                  <option value="">- SELECT -</option>
                  {rooms
                    .filter((r) => r.status === "Occupied")
                    .map((r) => (
                      <option key={r.number} value={r.number}>
                        Room {r.number}
                      </option>
                    ))}
                </select>
              </div>
              <div>
                <label className="ml-2 mb-3 block">เลขมิเตอร์น้ำใหม่</label>
                <input
                  type="number"
                  value={meterForm.water}
                  onChange={(e) =>
                    setMeterForm({ ...meterForm, water: e.target.value })
                  }
                  className="w-full p-4 bg-slate-50 border-none rounded-2xl font-bold"
                  placeholder="หน่วย"
                />
              </div>
              <div>
                <label className="ml-2 mb-3 block">เลขมิเตอร์ไฟใหม่</label>
                <input
                  type="number"
                  value={meterForm.electric}
                  onChange={(e) =>
                    setMeterForm({ ...meterForm, electric: e.target.value })
                  }
                  className="w-full p-4 bg-slate-50 border-none rounded-2xl font-bold"
                  placeholder="หน่วย"
                />
              </div>
              <button
                onClick={processBilling}
                className="bg-slate-900 text-white font-black h-[64px] rounded-[22px] hover:bg-black transition-all"
              >
                GENERATE BILL
              </button>
            </div>
            <div className="grid grid-cols-5 md:grid-cols-10 gap-4">
              {rooms.map((rm) => (
                <div
                  key={rm.number}
                  onClick={() =>
                    setRooms(
                      rooms.map((item) =>
                        item.number === rm.number
                          ? {
                              ...item,
                              status:
                                item.status === "Occupied"
                                  ? "Available"
                                  : "Occupied",
                              tenant:
                                item.status === "Occupied"
                                  ? "-"
                                  : "ผู้เช่าใหม่",
                            }
                          : item
                      )
                    )
                  }
                  className={`p-4 rounded-2xl text-center border-2 transition-all cursor-pointer ${
                    rm.status === "Available"
                      ? "border-dashed border-slate-200 opacity-20 hover:opacity-50"
                      : "bg-white shadow-sm font-black text-slate-700 border-white"
                  }`}
                >
                  {rm.number}
                </div>
              ))}
            </div>
          </div>
        )}

        {role === "admin" && activeMenu === "AdminParcels" && (
          <div className="space-y-10">
            <h1 className="text-3xl font-black italic uppercase tracking-tighter">
              Parcel Management
            </h1>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {rooms
                .filter((rm) => rm.status === "Occupied")
                .map((rm) => (
                  <div
                    key={rm.number}
                    className="bg-white p-8 rounded-[40px] shadow-sm border border-slate-100 flex flex-col items-center gap-4 text-center"
                  >
                    <div className="bg-slate-900 p-5 rounded-[25px] text-sky-400 mb-2">
                      <Package size={35} />
                    </div>
                    <h3 className="text-4xl font-black tracking-tighter italic">
                      Room {rm.number}
                    </h3>
                    <p className="text-slate-500 font-bold uppercase text-[10px] tracking-widest">
                      Unclaimed Parcels
                    </p>
                    <h2 className="text-5xl font-black text-red-500 mb-4">
                      {rm.parcels}
                    </h2>
                    <div className="flex gap-3 w-full mt-auto">
                      <button
                        onClick={() =>
                          setRooms(
                            rooms.map((item) =>
                              item.number === rm.number
                                ? { ...item, parcels: item.parcels + 1 }
                                : item
                            )
                          )
                        }
                        className="flex-1 py-4 bg-slate-900 text-white rounded-2xl font-black hover:bg-black uppercase text-[10px] tracking-widest transition-all"
                      >
                        + Add
                      </button>
                      <button
                        onClick={() => {
                          if (rm.parcels > 0)
                            setRooms(
                              rooms.map((item) =>
                                item.number === rm.number
                                  ? { ...item, parcels: 0 }
                                  : item
                              )
                            );
                        }}
                        className={`flex-1 py-4 rounded-2xl font-black uppercase text-[10px] tracking-widest transition-all ${
                          rm.parcels > 0
                            ? "bg-green-100 text-green-700 hover:bg-green-200 cursor-pointer"
                            : "bg-slate-50 text-slate-300 cursor-not-allowed"
                        }`}
                      >
                        Clear
                      </button>
                    </div>
                  </div>
                ))}
            </div>
          </div>
        )}

        {role === "admin" && activeMenu === "AdminPR" && (
          <div className="max-w-2xl bg-white p-10 rounded-[50px] shadow-sm border border-sky-50 font-black italic">
            <h2 className="text-2xl mb-8 uppercase tracking-tighter">
              Write News
            </h2>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                setAnnouncements([
                  {
                    id: Date.now(),
                    title: e.target.title.value,
                    content: e.target.content.value,
                    date: new Date().toLocaleDateString("th-TH"),
                  },
                  ...announcements,
                ]);
                e.target.reset();
                alert("โพสต์ข่าวสารสำเร็จ!");
              }}
              className="space-y-6"
            >
              <input
                name="title"
                placeholder="หัวข้อข่าว"
                className="w-full p-5 bg-slate-50 border-none rounded-2xl outline-none"
                required
              />
              <textarea
                name="content"
                rows="4"
                placeholder="เนื้อหาประกาศ..."
                className="w-full p-5 bg-slate-50 border-none rounded-2xl outline-none"
                required
              ></textarea>
              <button className="w-full bg-slate-900 text-white py-5 rounded-[22px] uppercase text-xs tracking-widest italic hover:bg-black transition-all">
                Post Announcement
              </button>
            </form>
          </div>
        )}

        {role === "admin" && activeMenu === "AdminComplaint" && (
          <div className="space-y-10">
            <h1 className="text-3xl font-black italic uppercase tracking-tighter">
              Room Complaints
            </h1>
            {complaints.length === 0 ? (
              <p className="text-slate-300 font-bold italic">
                No active complaints.
              </p>
            ) : (
              complaints.map((comp) => (
                <div
                  key={comp.id}
                  className="bg-white p-8 rounded-[40px] shadow-sm border flex flex-col md:flex-row justify-between items-center gap-8"
                >
                  <div className="flex gap-6 items-start">
                    {/* ✅ สลับไอคอนตามสถานะและประเภท */}
                    <div
                      className={`p-6 rounded-[30px] shadow-sm ${
                        comp.status === "รอดำเนินการ"
                          ? "bg-red-50 text-red-500"
                          : comp.status === "กำลังซ่อม" ||
                            comp.status === "รับเรื่องแล้ว"
                          ? "bg-yellow-50 text-yellow-500"
                          : "bg-green-50 text-green-500"
                      }`}
                    >
                      {comp.status === "รอดำเนินการ" &&
                      comp.type === "ร้องเรียน" ? (
                        <Users size={35} />
                      ) : comp.status === "รอดำเนินการ" ? (
                        <AlertCircle size={35} />
                      ) : comp.status === "กำลังซ่อม" ? (
                        <Wrench size={35} />
                      ) : comp.status === "รับเรื่องแล้ว" ? (
                        <MessageSquare size={35} />
                      ) : (
                        <CheckCircle2 size={35} />
                      )}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span
                          className={`px-2 py-1 rounded text-[10px] font-black tracking-widest text-white ${
                            comp.type === "แจ้งซ่อม"
                              ? "bg-sky-500"
                              : "bg-purple-500"
                          }`}
                        >
                          {comp.type}
                        </span>
                        <h3 className="text-2xl font-black italic uppercase tracking-tighter">
                          Room {comp.room}
                        </h3>
                      </div>
                      <p className="text-lg font-black mt-2">{comp.topic}</p>
                      <p className="text-slate-500 font-bold mt-1">
                        {comp.detail}
                      </p>
                      <p className="text-[10px] font-black uppercase tracking-widest mt-4">
                        Date: {comp.date} | Status:{" "}
                        <span
                          className={
                            comp.status === "รอดำเนินการ"
                              ? "text-red-400"
                              : comp.status === "กำลังซ่อม" ||
                                comp.status === "รับเรื่องแล้ว"
                              ? "text-yellow-500"
                              : "text-green-500"
                          }
                        >
                          {comp.status}
                        </span>
                      </p>
                    </div>
                  </div>

                  {/* ✅ ส่วนปุ่มกดของแอดมิน เปลี่ยนคำตาม Type ปัญหา */}
                  <div className="flex gap-4">
                    {comp.status === "รอดำเนินการ" ? (
                      <button
                        onClick={() =>
                          setComplaints(
                            complaints.map((c) =>
                              c.id === comp.id
                                ? {
                                    ...c,
                                    status:
                                      c.type === "แจ้งซ่อม"
                                        ? "กำลังซ่อม"
                                        : "รับเรื่องแล้ว",
                                  }
                                : c
                            )
                          )
                        }
                        className="px-8 py-5 bg-yellow-400 text-white font-black rounded-[25px] hover:bg-yellow-500 uppercase text-xs tracking-widest italic transition-all"
                      >
                        {comp.type === "แจ้งซ่อม"
                          ? "รับเรื่องซ่อม"
                          : "รับเรื่อง"}
                      </button>
                    ) : comp.status === "กำลังซ่อม" ? (
                      <button
                        onClick={() =>
                          setComplaints(
                            complaints.map((c) =>
                              c.id === comp.id
                                ? { ...c, status: "ซ่อมเสร็จแล้ว" }
                                : c
                            )
                          )
                        }
                        className="px-8 py-5 bg-green-500 text-white font-black rounded-[25px] hover:bg-green-600 uppercase text-xs tracking-widest italic transition-all"
                      >
                        ซ่อมเสร็จแล้ว
                      </button>
                    ) : comp.status === "รับเรื่องแล้ว" ? (
                      <button
                        onClick={() =>
                          setComplaints(
                            complaints.map((c) =>
                              c.id === comp.id
                                ? { ...c, status: "จัดการเรียบร้อย" }
                                : c
                            )
                          )
                        }
                        className="px-8 py-5 bg-green-500 text-white font-black rounded-[25px] hover:bg-green-600 uppercase text-xs tracking-widest italic transition-all"
                      >
                        จัดการเรียบร้อย
                      </button>
                    ) : (
                      <button
                        onClick={() =>
                          setComplaints(
                            complaints.filter((c) => c.id !== comp.id)
                          )
                        }
                        className="px-8 py-5 bg-slate-200 text-slate-500 font-black rounded-[25px] hover:bg-slate-300 uppercase text-xs tracking-widest italic transition-all"
                      >
                        ลบประวัติ
                      </button>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        )}

        {role === "admin" && activeMenu === "Verify" && (
          <div className="space-y-10">
            <h1 className="text-3xl font-black italic uppercase tracking-tighter">
              Audit Slips
            </h1>
            {rooms.filter((rm) => rm.paymentStatus === "pending").length ===
            0 ? (
              <div className="bg-white p-32 rounded-[70px] text-center font-black text-slate-100 text-6xl italic border-2 border-dashed uppercase tracking-tighter">
                No Slips
              </div>
            ) : (
              rooms
                .filter((rm) => rm.paymentStatus === "pending")
                .map((rm) => (
                  <div
                    key={rm.number}
                    className="bg-white p-10 rounded-[60px] shadow-sm border flex flex-col md:flex-row justify-between items-center gap-12 font-bold transition-all"
                  >
                    <div className="flex flex-col md:flex-row items-center gap-8 w-full md:w-auto">
                      <div className="bg-slate-100 w-32 h-52 rounded-[40px] flex items-center justify-center border-2 border-dashed border-slate-200 overflow-hidden">
                        {rm.slipImage ? (
                          <img
                            src={rm.slipImage}
                            alt="slip"
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <span className="text-slate-300 font-black text-[10px] uppercase tracking-widest">
                            No Img
                          </span>
                        )}
                      </div>
                      <div className="text-center md:text-left">
                        <h3 className="text-6xl font-black tracking-tighter italic">
                          Room {rm.number}
                        </h3>
                        <p className="text-3xl font-black text-sky-600 mt-2">
                          ฿ {rm.totalBill.toLocaleString()}
                        </p>
                      </div>
                    </div>
                    <div className="flex gap-4">
                      <button
                        onClick={() =>
                          setRooms(
                            rooms.map((item) =>
                              item.number === rm.number
                                ? {
                                    ...item,
                                    paymentStatus: "unpaid",
                                    slipImage: null,
                                  }
                                : item
                            )
                          )
                        }
                        className="px-10 py-6 rounded-[30px] bg-red-50 text-red-600 font-black uppercase text-xs hover:bg-red-100 transition-all"
                      >
                        Reject
                      </button>
                      <button
                        onClick={() =>
                          setRooms(
                            rooms.map((item) =>
                              item.number === rm.number
                                ? { ...item, paymentStatus: "paid" }
                                : item
                            )
                          )
                        }
                        className="px-16 py-6 rounded-[30px] bg-slate-900 text-white font-black shadow-2xl hover:bg-black transition-all uppercase text-xs"
                      >
                        Approve
                      </button>
                    </div>
                  </div>
                ))
            )}
          </div>
        )}
      </div>
    </div>
  );
}
