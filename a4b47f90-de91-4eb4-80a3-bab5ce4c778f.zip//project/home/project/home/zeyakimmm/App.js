import React, { useState } from "react";
import {
  LayoutDashboard,
  BedSingle,
  HandCoins,
  Settings,
  LogOut,
  CheckCircle2,
  UserCircle,
  Clock,
  Home,
  Wrench,
  Package,
  Send,
  QrCode,
  Lock,
  Upload,
  History,
  Megaphone,
  CheckSquare,
  XCircle,
  Zap,
  Calculator,
} from "lucide-react";

export default function App() {
  const [role, setRole] = useState(null);
  const [currentUser, setCurrentUser] = useState(null);
  const [activeMenu, setActiveMenu] = useState("Dashboard");

  // ==========================================
  // ข้อมูลจำลองหอพัก (สมจริง: เก็บเลขมิเตอร์ครั้งก่อน-ครั้งนี้)
  // ==========================================
  const [rooms, setRooms] = useState(() => {
    const initialRooms = [];
    for (let floor = 1; floor <= 5; floor++) {
      for (let i = 1; i <= 5; i++) {
        let roomNum = `${floor}0${i}`;
        let isOccupied = roomNum === "101" ? true : Math.random() > 0.4;
        initialRooms.push({
          number: roomNum,
          floor: floor,
          status: isOccupied ? "Occupied" : "Available",
          tenant: isOccupied
            ? roomNum === "101"
              ? "ธาราทิพย์ คิม"
              : `ผู้เช่าห้อง ${roomNum}`
            : "-",
          paymentStatus: isOccupied ? "unpaid" : "none",
          rent: 3500,
          // ระบบมิเตอร์
          prevWater: 100, // เลขมิเตอร์น้ำเดือนก่อน
          currWater: 100, // เลขมิเตอร์น้ำปัจจุบัน
          prevElectric: 500, // เลขมิเตอร์ไฟเดือนก่อน
          currElectric: 500, // เลขมิเตอร์ไฟปัจจุบัน
          parcels: isOccupied ? Math.floor(Math.random() * 3) : 0,
        });
      }
    }
    return initialRooms;
  });

  const [tickets, setTickets] = useState([
    {
      id: 1,
      room: "101",
      issue: "แอร์ไม่เย็น",
      detail: "มีลมแต่ไม่เย็น",
      status: "รอมอบหมายช่าง",
      date: "07 เม.ย. 2026",
    },
  ]);

  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [loginTab, setLoginTab] = useState("user");

  // ==========================================
  // ฟังก์ชันคำนวณ (Business Logic)
  // ==========================================
  const WATER_RATE = 20; // บาทต่อหน่วย
  const ELECTRIC_RATE = 8; // บาทต่อหน่วย

  const calculateRoomTotal = (room) => {
    const waterUnits = room.currWater - room.prevWater;
    const electricUnits = room.currElectric - room.prevElectric;
    const waterBill = waterUnits > 0 ? waterUnits * WATER_RATE : 0;
    const electricBill = electricUnits > 0 ? electricUnits * ELECTRIC_RATE : 0;
    return {
      waterUnits,
      electricUnits,
      waterBill,
      electricBill,
      grandTotal: room.rent + waterBill + electricBill,
    };
  };

  // ==========================================
  // ACTIONS
  // ==========================================
  const [meterForm, setMeterForm] = useState({
    room: "",
    water: "",
    electric: "",
  });

  const switchTab = (tab) => {
    setLoginTab(tab);
    setUsername("");
    setPassword("");
  };

  const handleLogin = (e) => {
    e.preventDefault();
    if (loginTab === "admin") {
      if (username === "admin" && password === "admin1234") {
        setRole("admin");
        setActiveMenu("Dashboard");
      } else {
        alert("ID แอดมิน หรือรหัสผ่านไม่ถูกต้อง!");
      }
    } else {
      const foundRoom = rooms.find((r) => r.number === username);
      if (foundRoom && foundRoom.status === "Occupied" && password === "1234") {
        setCurrentUser(foundRoom.number);
        setRole("user");
        setActiveMenu("Home");
      } else {
        alert("หมายเลขห้องหรือรหัสผ่านผิด!");
      }
    }
  };

  const saveMeterData = () => {
    if (!meterForm.room || !meterForm.water || !meterForm.electric) return;
    setRooms(
      rooms.map((r) => {
        if (r.number === meterForm.room) {
          return {
            ...r,
            prevWater: r.currWater, // เลื่อนเลขปัจจุบันไปเป็นเลขก่อนหน้า
            currWater: parseInt(meterForm.water),
            prevElectric: r.currElectric,
            currElectric: parseInt(meterForm.electric),
            paymentStatus: "unpaid",
          };
        }
        return r;
      })
    );
    alert(`บันทึกมิเตอร์ห้อง ${meterForm.room} เรียบร้อย!`);
    setMeterForm({ room: "", water: "", electric: "" });
  };

  // ==========================================
  // UI - LOGIN
  // ==========================================
  if (role === null) {
    return (
      <div
        className="min-h-screen bg-slate-100 flex items-center justify-center p-4"
        style={{ fontFamily: "Sarabun, sans-serif" }}
      >
        <div className="bg-white p-10 rounded-[40px] shadow-2xl max-w-md w-full border border-gray-100">
          <div className="text-center mb-8">
            <div className="bg-sky-50 w-20 h-20 rounded-3xl flex items-center justify-center mx-auto mb-4">
              <BedSingle className="w-10 h-10 text-sky-600" />
            </div>
            <h1 className="text-3xl font-black text-sky-900">S.T. Dormitory</h1>
          </div>

          <div className="flex mb-8 bg-slate-100 p-1.5 rounded-2xl">
            <button
              onClick={() => switchTab("user")}
              className={`flex-1 py-3 rounded-xl text-sm font-bold transition-all ${
                loginTab === "user"
                  ? "bg-white shadow-md text-sky-600"
                  : "text-gray-400"
              }`}
            >
              ผู้เช่า
            </button>
            <button
              onClick={() => switchTab("admin")}
              className={`flex-1 py-3 rounded-xl text-sm font-bold transition-all ${
                loginTab === "admin"
                  ? "bg-white shadow-md text-sky-600"
                  : "text-gray-400"
              }`}
            >
              แอดมิน
            </button>
          </div>

          <form onSubmit={handleLogin} className="space-y-6">
            <div>
              <label className="block text-sm font-bold text-gray-600 mb-2 ml-1">
                {loginTab === "user" ? "หมายเลขห้อง" : "Username แอดมิน"}
              </label>
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full p-4 bg-slate-50 border-2 border-slate-100 rounded-2xl outline-none focus:border-sky-500 focus:bg-white transition-all font-bold"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-bold text-gray-600 mb-2 ml-1">
                รหัสผ่าน
              </label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full p-4 bg-slate-50 border-2 border-slate-100 rounded-2xl outline-none focus:border-sky-500 focus:bg-white transition-all font-bold"
                required
              />
            </div>
            <button className="w-full py-4 bg-sky-600 text-white font-black rounded-2xl hover:bg-sky-700 shadow-xl shadow-sky-100 transition-all text-lg">
              เข้าสู่ระบบ
            </button>
          </form>
        </div>
      </div>
    );
  }

  // ==========================================
  // UI - TENANT
  // ==========================================
  if (role === "user") {
    const r = rooms.find((room) => room.number === currentUser);
    const bill = calculateRoomTotal(r);

    return (
      <div className="min-h-screen bg-slate-50 flex flex-col md:flex-row">
        <div className="w-full md:w-64 bg-white shadow-xl p-6 flex flex-col z-20">
          <h2 className="font-black text-sky-600 text-2xl mb-10">S.T. DORM</h2>
          <nav className="flex-1 space-y-3">
            <button
              onClick={() => setActiveMenu("Home")}
              className={`w-full flex items-center gap-3 p-4 rounded-2xl font-bold transition-all ${
                activeMenu === "Home"
                  ? "bg-sky-50 text-sky-700 shadow-sm"
                  : "text-gray-400 hover:bg-gray-50"
              }`}
            >
              <Home size={22} /> หน้าหลัก
            </button>
            <button
              onClick={() => setActiveMenu("Bill")}
              className={`w-full flex items-center gap-3 p-4 rounded-2xl font-bold transition-all ${
                activeMenu === "Bill"
                  ? "bg-sky-50 text-sky-700 shadow-sm"
                  : "text-gray-400 hover:bg-gray-50"
              }`}
            >
              <HandCoins size={22} /> ค่าเช่า/น้ำไฟ
            </button>
            <button
              onClick={() => setActiveMenu("Repair")}
              className={`w-full flex items-center gap-3 p-4 rounded-2xl font-bold transition-all ${
                activeMenu === "Repair"
                  ? "bg-sky-50 text-sky-700 shadow-sm"
                  : "text-gray-400 hover:bg-gray-50"
              }`}
            >
              <Wrench size={22} /> แจ้งซ่อม
            </button>
          </nav>
          <button
            onClick={() => setRole(null)}
            className="flex items-center gap-3 text-red-500 p-4 mt-auto font-bold hover:bg-red-50 rounded-2xl transition-all"
          >
            <LogOut size={22} /> ออกจากระบบ
          </button>
        </div>

        <div className="flex-1 p-8 overflow-y-auto">
          {activeMenu === "Home" && (
            <div className="max-w-4xl space-y-8">
              <h1 className="text-3xl font-black text-slate-800">
                สรุปภาพรวมห้อง {currentUser}
              </h1>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="bg-white p-8 rounded-[40px] shadow-sm border border-sky-100">
                  <p className="text-gray-400 font-bold uppercase text-xs tracking-widest">
                    ยอดชำระเดือนปัจจุบัน
                  </p>
                  <h2 className="text-5xl font-black mt-4 text-slate-800">
                    ฿ {bill.grandTotal.toLocaleString()}
                  </h2>
                  <div
                    className={`mt-6 inline-flex items-center gap-2 px-4 py-2 rounded-full font-black text-sm ${
                      r.paymentStatus === "paid"
                        ? "bg-green-100 text-green-600"
                        : "bg-red-100 text-red-600"
                    }`}
                  >
                    {r.paymentStatus === "paid" ? (
                      <CheckCircle2 size={18} />
                    ) : (
                      <Clock size={18} />
                    )}
                    {r.paymentStatus === "paid" ? "ชำระแล้ว" : "ค้างชำระ"}
                  </div>
                </div>
                <div className="bg-white p-8 rounded-[40px] shadow-sm border border-sky-100 flex items-center gap-6">
                  <div className="bg-orange-100 p-5 rounded-3xl text-orange-600">
                    <Package size={40} />
                  </div>
                  <div>
                    <p className="text-gray-400 font-bold uppercase text-xs">
                      พัสดุรอรับ
                    </p>
                    <h2 className="text-4xl font-black text-slate-800">
                      {r.parcels}{" "}
                      <span className="text-lg font-bold text-gray-300">
                        ชิ้น
                      </span>
                    </h2>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeMenu === "Bill" && (
            <div className="max-w-5xl mx-auto bg-white p-10 rounded-[45px] shadow-sm border border-slate-100 flex flex-col md:flex-row gap-12">
              <div className="flex-1 space-y-8">
                <h2 className="text-2xl font-black text-slate-800 border-b-2 border-slate-50 pb-6">
                  ใบแจ้งหนี้ Digital
                </h2>
                <div className="space-y-5">
                  <div className="flex justify-between text-lg">
                    <span className="text-gray-500 font-bold">
                      ค่าเช่าห้องพัก (รายเดือน)
                    </span>
                    <span className="font-black text-slate-800">
                      ฿ {r.rent.toLocaleString()}
                    </span>
                  </div>
                  <div className="flex justify-between text-lg items-center">
                    <div>
                      <p className="text-gray-500 font-bold">ค่าน้ำประปา</p>
                      <p className="text-xs text-gray-400 italic">
                        เลขมิเตอร์: {r.prevWater} - {r.currWater} (
                        {bill.waterUnits} หน่วย)
                      </p>
                    </div>
                    <span className="font-black text-slate-800">
                      ฿ {bill.waterBill.toLocaleString()}
                    </span>
                  </div>
                  <div className="flex justify-between text-lg items-center">
                    <div>
                      <p className="text-gray-500 font-bold">ค่าไฟฟ้า</p>
                      <p className="text-xs text-gray-400 italic">
                        เลขมิเตอร์: {r.prevElectric} - {r.currElectric} (
                        {bill.electricUnits} หน่วย)
                      </p>
                    </div>
                    <span className="font-black text-slate-800">
                      ฿ {bill.electricBill.toLocaleString()}
                    </span>
                  </div>
                  <div className="flex justify-between text-3xl font-black text-sky-600 border-t-2 border-slate-50 pt-8">
                    <span>ยอดที่ต้องชำระ</span>
                    <span>฿ {bill.grandTotal.toLocaleString()}</span>
                  </div>
                </div>
              </div>
              <div className="w-full md:w-80 flex flex-col items-center justify-center border-t md:border-t-0 md:border-l-2 border-slate-50 pt-10 md:pt-0 md:pl-12">
                {r.paymentStatus === "unpaid" ? (
                  <>
                    <p className="font-black text-slate-800 mb-6 text-center">
                      สแกนเพื่อจ่ายเงิน
                    </p>
                    <div className="bg-slate-50 p-6 rounded-[35px] mb-8 border border-slate-100 shadow-inner">
                      <QrCode size={180} className="text-slate-800" />
                    </div>
                    <button
                      onClick={() => {
                        setRooms(
                          rooms.map((room) =>
                            room.number === currentUser
                              ? { ...room, paymentStatus: "pending" }
                              : room
                          )
                        );
                        alert("แจ้งโอนเรียบร้อย!");
                      }}
                      className="w-full bg-sky-600 text-white font-black py-5 rounded-2xl shadow-xl shadow-sky-100 hover:bg-sky-700 flex items-center justify-center gap-2 transition-all"
                    >
                      <Upload size={22} /> แจ้งโอนเงิน
                    </button>
                  </>
                ) : (
                  <div className="text-center">
                    <div
                      className={`${
                        r.paymentStatus === "pending"
                          ? "bg-yellow-50 text-yellow-500"
                          : "bg-green-50 text-green-500"
                      } w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-6 shadow-sm`}
                    >
                      {r.paymentStatus === "pending" ? (
                        <Clock size={50} />
                      ) : (
                        <CheckCircle2 size={50} />
                      )}
                    </div>
                    <h3 className="text-2xl font-black text-slate-800 mb-2">
                      {r.paymentStatus === "pending"
                        ? "รอตรวจสอบ"
                        : "จ่ายเงินแล้ว"}
                    </h3>
                    <p className="text-gray-400 font-bold">
                      บันทึกข้อมูลเรียบร้อย
                    </p>
                  </div>
                )}
              </div>
            </div>
          )}

          {activeMenu === "Repair" && (
            <div className="max-w-3xl mx-auto space-y-10">
              <div className="bg-white p-10 rounded-[40px] shadow-sm border border-orange-50">
                <h2 className="text-2xl font-black mb-8 text-orange-600 flex items-center gap-2">
                  <Wrench /> แจ้งซ่อมออนไลน์
                </h2>
                <form
                  className="space-y-6"
                  onSubmit={(e) => {
                    e.preventDefault();
                    setTickets([
                      {
                        id: Date.now(),
                        room: currentUser,
                        issue: e.target.issue.value,
                        detail: e.target.detail.value,
                        status: "รับเรื่องแล้ว",
                        date: "07 เม.ย. 2026",
                      },
                      ...tickets,
                    ]);
                    e.target.reset();
                    alert("ส่งเรื่องสำเร็จ!");
                  }}
                >
                  <input
                    name="issue"
                    placeholder="ระบุปัญหา (เช่น ไฟทางเดินขาด, แอร์เสียงดัง)"
                    className="w-full p-4 bg-slate-50 border-2 border-slate-50 rounded-2xl font-black outline-none focus:border-orange-400 focus:bg-white transition-all"
                    required
                  />
                  <textarea
                    name="detail"
                    rows="3"
                    placeholder="ระบุรายละเอียดเพิ่มเติม..."
                    className="w-full p-4 bg-slate-50 border-2 border-slate-50 rounded-2xl font-bold outline-none focus:border-orange-400 focus:bg-white transition-all"
                  ></textarea>
                  <button className="w-full bg-orange-500 text-white font-black py-5 rounded-2xl flex items-center justify-center gap-2 hover:bg-orange-600 shadow-xl shadow-orange-100 transition-all">
                    <Send size={22} /> ส่งข้อมูล
                  </button>
                </form>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  // ==========================================
  // UI - ADMIN
  // ==========================================
  if (role === "admin") {
    const pending = rooms.filter((r) => r.paymentStatus === "pending");

    return (
      <div className="min-h-screen bg-slate-50 flex flex-col md:flex-row">
        <div className="w-full md:w-72 bg-slate-900 shadow-2xl p-8 flex flex-col text-white z-20">
          <h2 className="text-2xl font-black mb-12 text-sky-400">
            ADMIN PANEL
          </h2>
          <nav className="flex-1 space-y-4">
            <button
              onClick={() => setActiveMenu("Dashboard")}
              className={`w-full flex items-center gap-4 p-4 rounded-2xl font-bold transition-all ${
                activeMenu === "Dashboard"
                  ? "bg-slate-800 text-sky-400 shadow-lg"
                  : "text-slate-500 hover:text-white"
              }`}
            >
              <LayoutDashboard size={24} /> Dashboard
            </button>
            <button
              onClick={() => setActiveMenu("Rooms")}
              className={`w-full flex items-center gap-4 p-4 rounded-2xl font-bold transition-all ${
                activeMenu === "Rooms"
                  ? "bg-slate-800 text-sky-400 shadow-lg"
                  : "text-slate-500 hover:text-white"
              }`}
            >
              <Calculator size={24} /> บันทึกมิเตอร์
            </button>
            <button
              onClick={() => setActiveMenu("Verify")}
              className={`w-full flex items-center gap-4 p-4 rounded-2xl font-bold transition-all ${
                activeMenu === "Verify"
                  ? "bg-slate-800 text-sky-400 shadow-lg"
                  : "text-slate-500 hover:text-white"
              }`}
            >
              <CheckSquare size={24} /> ตรวจสลิป ({pending.length})
            </button>
          </nav>
          <button
            onClick={() => setRole(null)}
            className="flex items-center gap-4 text-red-400 p-4 mt-auto font-bold hover:bg-slate-800 rounded-2xl transition-all"
          >
            <LogOut size={24} /> LOGOUT
          </button>
        </div>

        <div className="flex-1 p-10 overflow-y-auto">
          {activeMenu === "Dashboard" && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="bg-white p-8 rounded-[40px] shadow-sm border-l-[10px] border-sky-500">
                <p className="text-gray-400 font-black uppercase text-xs tracking-widest">
                  ผู้เช่ารวม
                </p>
                <h2 className="text-5xl font-black mt-3 text-slate-800">
                  {rooms.filter((r) => r.status === "Occupied").length}
                </h2>
              </div>
              <div className="bg-white p-8 rounded-[40px] shadow-sm border-l-[10px] border-red-500">
                <p className="text-gray-400 font-black uppercase text-xs tracking-widest">
                  รอยืนยันสลิป
                </p>
                <h2 className="text-5xl font-black mt-3 text-red-600">
                  {pending.length}
                </h2>
              </div>
            </div>
          )}

          {activeMenu === "Rooms" && (
            <div className="space-y-10">
              <div className="bg-white p-10 rounded-[45px] shadow-sm border border-slate-100 space-y-8">
                <h2 className="text-2xl font-black text-slate-800">
                  บันทึกเลขมิเตอร์ประจำเดือน
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-6 items-end">
                  <div className="col-span-1 md:col-span-1">
                    <label className="text-sm font-black text-slate-400 ml-2 uppercase">
                      ห้องพัก
                    </label>
                    <select
                      onChange={(e) =>
                        setMeterForm({ ...meterForm, room: e.target.value })
                      }
                      value={meterForm.room}
                      className="w-full p-4 bg-slate-50 border-2 border-slate-50 rounded-2xl font-black outline-none mt-2 focus:bg-white focus:border-sky-500 transition-all"
                    >
                      <option value="">เลือกห้อง</option>
                      {rooms
                        .filter((r) => r.status === "Occupied")
                        .map((r) => (
                          <option key={r.number} value={r.number}>
                            Room {r.number}
                          </option>
                        ))}
                    </select>
                  </div>
                  <div>
                    <label className="text-sm font-black text-slate-400 ml-2 uppercase">
                      เลขมิเตอร์น้ำ
                    </label>
                    <input
                      type="number"
                      value={meterForm.water}
                      onChange={(e) =>
                        setMeterForm({ ...meterForm, water: e.target.value })
                      }
                      className="w-full p-4 bg-slate-50 border-2 border-slate-50 rounded-2xl font-black outline-none mt-2"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-black text-slate-400 ml-2 uppercase">
                      เลขมิเตอร์ไฟ
                    </label>
                    <input
                      type="number"
                      value={meterForm.electric}
                      onChange={(e) =>
                        setMeterForm({ ...meterForm, electric: e.target.value })
                      }
                      className="w-full p-4 bg-slate-50 border-2 border-slate-50 rounded-2xl font-black outline-none mt-2"
                    />
                  </div>
                  <button
                    onClick={saveMeterData}
                    className="bg-slate-900 text-white font-black h-16 px-10 rounded-2xl hover:bg-black transition-all flex items-center justify-center gap-2"
                  >
                    <Zap size={20} /> ออกบิล
                  </button>
                </div>
              </div>
              <div className="grid grid-cols-5 md:grid-cols-10 gap-3">
                {rooms.map((r) => (
                  <div
                    key={r.number}
                    className={`p-4 rounded-2xl text-center border-2 transition-all ${
                      r.status === "Available"
                        ? "border-dashed border-slate-200 opacity-30"
                        : r.paymentStatus === "paid"
                        ? "bg-green-50 border-green-200 text-green-600 font-bold"
                        : "bg-white border-white shadow-sm font-black"
                    }`}
                  >
                    <p className="text-xs uppercase">{r.number}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeMenu === "Verify" && (
            <div className="space-y-8">
              <h1 className="text-3xl font-black text-slate-800">
                ตรวจสอบการโอนเงิน
              </h1>
              {pending.length === 0 ? (
                <div className="bg-white p-20 rounded-[45px] text-center border-2 border-dashed border-slate-200 text-slate-300 font-black text-2xl uppercase tracking-tighter">
                  No Pending Slips
                </div>
              ) : (
                pending.map((r) => {
                  const b = calculateRoomTotal(r);
                  return (
                    <div
                      key={r.number}
                      className="bg-white p-8 rounded-[40px] shadow-sm border flex flex-col md:flex-row justify-between items-center gap-8"
                    >
                      <div className="flex items-center gap-8">
                        <div className="bg-slate-100 w-32 h-44 rounded-3xl flex flex-col items-center justify-center border-2 border-dashed border-slate-200 text-slate-400 font-black text-[10px]">
                          <Upload size={30} className="mb-2" />
                          VIEW SLIP
                        </div>
                        <div>
                          <h3 className="text-3xl font-black text-slate-800 uppercase italic">
                            Room {r.number}
                          </h3>
                          <p className="text-xl font-bold text-sky-600 mt-1">
                            ยอดโอน: ฿ {b.grandTotal.toLocaleString()}
                          </p>
                          <p className="text-slate-400 font-bold mt-2">
                            ผู้เช่า: {r.tenant}
                          </p>
                        </div>
                      </div>
                      <div className="flex gap-4 w-full md:w-auto">
                        <button
                          onClick={() => {
                            setRooms(
                              rooms.map((room) =>
                                room.number === r.number
                                  ? { ...room, paymentStatus: "unpaid" }
                                  : room
                              )
                            );
                            alert("ปฏิเสธเรียบร้อย");
                          }}
                          className="flex-1 px-8 py-4 rounded-2xl bg-red-50 text-red-600 font-black hover:bg-red-100 transition-all uppercase"
                        >
                          Reject
                        </button>
                        <button
                          onClick={() => {
                            setRooms(
                              rooms.map((room) =>
                                room.number === r.number
                                  ? { ...room, paymentStatus: "paid" }
                                  : room
                              )
                            );
                            alert("อนุมัติสำเร็จ!");
                          }}
                          className="flex-1 px-12 py-4 rounded-2xl bg-green-500 text-white font-black shadow-xl shadow-green-100 hover:bg-green-600 transition-all uppercase"
                        >
                          Approve
                        </button>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          )}
        </div>
      </div>
    );
  }
  return null;
}
